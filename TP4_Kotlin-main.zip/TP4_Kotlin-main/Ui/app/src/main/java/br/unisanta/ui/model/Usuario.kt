package br.unisanta.ui.controller.model

data class Usuario(
    val email: String,
    val senha: String
)