package br.unisanta.ui.view

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.ui.R

class UsuarioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val txvEmail = itemView.findViewById<TextView>(R.id.txv_email)
}