package br.unisanta.ui.controller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.unisanta.ui.R
import br.unisanta.ui.controller.adapter.UsuarioAdapter
import br.unisanta.ui.model.UsuarioDAO

class ListaUsuariosActivity : AppCompatActivity(R.layout.activity_lista_usuarios) {
    private val dao = UsuarioDAO()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rvUsuarios = findViewById<RecyclerView>(R.id.rv_usuarios)
        val usuarios = dao.get()

        rvUsuarios.layoutManager = LinearLayoutManager(this)
        rvUsuarios.adapter = UsuarioAdapter(usuarios)
    }
}